from .simple_ma import SMACrossoverStrategy
